﻿namespace LojaDeGames
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGames = new System.Windows.Forms.Label();
            this.lblJogo1 = new System.Windows.Forms.Label();
            this.txtJogo1 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblJogo2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblGames
            // 
            this.lblGames.AutoSize = true;
            this.lblGames.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblGames.Location = new System.Drawing.Point(283, 28);
            this.lblGames.Name = "lblGames";
            this.lblGames.Size = new System.Drawing.Size(229, 45);
            this.lblGames.TabIndex = 0;
            this.lblGames.Text = "Loja de Games";
            this.lblGames.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblJogo1
            // 
            this.lblJogo1.AutoSize = true;
            this.lblJogo1.Location = new System.Drawing.Point(77, 120);
            this.lblJogo1.Name = "lblJogo1";
            this.lblJogo1.Size = new System.Drawing.Size(38, 15);
            this.lblJogo1.TabIndex = 1;
            this.lblJogo1.Text = "Jogo1";
            // 
            // txtJogo1
            // 
            this.txtJogo1.Location = new System.Drawing.Point(162, 119);
            this.txtJogo1.Name = "txtJogo1";
            this.txtJogo1.Size = new System.Drawing.Size(100, 23);
            this.txtJogo1.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(162, 199);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 4;
            // 
            // lblJogo2
            // 
            this.lblJogo2.AutoSize = true;
            this.lblJogo2.Location = new System.Drawing.Point(77, 200);
            this.lblJogo2.Name = "lblJogo2";
            this.lblJogo2.Size = new System.Drawing.Size(38, 15);
            this.lblJogo2.TabIndex = 3;
            this.lblJogo2.Text = "Jogo2";
            this.lblJogo2.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(162, 277);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 23);
            this.textBox2.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(77, 278);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Jogo3";
            this.label3.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtPreco3
            // 
            this.txtPreco3.Location = new System.Drawing.Point(481, 278);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(100, 23);
            this.txtPreco3.TabIndex = 12;
            this.txtPreco3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Location = new System.Drawing.Point(384, 280);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(91, 15);
            this.lblPreco3.TabIndex = 11;
            this.lblPreco3.Text = "Preco do Jogo 3";
            this.lblPreco3.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // txtPreco2
            // 
            this.txtPreco2.Location = new System.Drawing.Point(481, 200);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(100, 23);
            this.txtPreco2.TabIndex = 10;
            this.txtPreco2.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Location = new System.Drawing.Point(384, 202);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(91, 15);
            this.lblPreco2.TabIndex = 9;
            this.lblPreco2.Text = "Preço do Jogo 2";
            this.lblPreco2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // txtPreco1
            // 
            this.txtPreco1.Location = new System.Drawing.Point(481, 120);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(100, 23);
            this.txtPreco1.TabIndex = 8;
            this.txtPreco1.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.Location = new System.Drawing.Point(384, 120);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(91, 15);
            this.lblPreco1.TabIndex = 7;
            this.lblPreco1.Text = "Preço do Jogo 1";
            this.lblPreco1.Click += new System.EventHandler(this.label4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtPreco3);
            this.Controls.Add(this.lblPreco3);
            this.Controls.Add(this.txtPreco2);
            this.Controls.Add(this.lblPreco2);
            this.Controls.Add(this.txtPreco1);
            this.Controls.Add(this.lblPreco1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblJogo2);
            this.Controls.Add(this.txtJogo1);
            this.Controls.Add(this.lblJogo1);
            this.Controls.Add(this.lblGames);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblGames;
        private Label lblJogo1;
        private TextBox txtJogo1;
        private TextBox textBox1;
        private Label lblJogo2;
        private TextBox textBox2;
        private Label label3;
        private TextBox txtPreco3;
        private Label lblPreco3;
        private TextBox txtPreco2;
        private Label lblPreco2;
        private TextBox txtPreco1;
        private Label lblPreco1;
    }
}