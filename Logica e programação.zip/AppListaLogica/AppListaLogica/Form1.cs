namespace AppListaLogica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Bem vinda a atividade do melhor aluno");

        }



        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;

            media = (num1 + num2 + num3) / 3;

            MessageBox.Show("M�dia = " + media);
        }



        private void btnSominha_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float soma;

            soma = num1 + num3;

            MessageBox.Show("Soma = " + soma);

        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);

            float porcentagem1;
            float porcentagem2;
            float porcentagem3;

            porcentagem1 = num1 / (num1 + num2 + num3) * 100;
            porcentagem2 = num2 / (num1 + num2 + num3) * 100;
            porcentagem3 = num3 / (num1 + num2 + num3) * 100;

            MessageBox.Show ("Porcentagem 1 = " + porcentagem1 + "Porcentagem 2 = " + porcentagem2 + "Porcentagem 3 = " + porcentagem3);
        }
    }
}