﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicativoAula02_21_02_22
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Bem vindo a calculadora do melhor aluno");
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float resultado;
            resultado = Num1 - Num2;
            MessageBox.Show("resultado: " + resultado);
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float resultado;
            resultado = Num1 * Num2;
            MessageBox.Show("resultado: " + resultado);
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float resultado;
            resultado = Num1 / Num2;
            MessageBox.Show("resultado: " + resultado);
        }

        private void btnAdicao_Click_1(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float resultado;
            resultado = Num1 + Num2;
            MessageBox.Show("resultado: " + resultado);
        }
    }
}

     
